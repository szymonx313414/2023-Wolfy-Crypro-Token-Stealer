-> If you need help with our software or you want to purchase PRO version, then please contact us on Telegram: https://t.me/zelvafrancek420


## Features:
»Startup

»Discord injection

» Grab Discord Information and HQ Friends.

» Grab Password & cookies.

» Grab Files.

» Shows Crypto Wallets

» Grab metamask/exodus

» Grab Telegram

» Grab chromium based Passwords


## Setup:

- start 'install_python'

- open `install.bat`

- and then open `builder.bat`


##  Manual Setup:
 
First paste and save your webhook address instead of `"WEBHOOK HERE"` in Wolfy.py

If you use obfuscator it will be undetectable.

if you have an error while installing try `pip install -r requirements.txt`

Now You need to use pyinstaller to convert python file to exe.

Open CMD and type `pip install auto_py_to_exe`

And after installed `python -m auto_py_to_exe`

Browse file Select `One file and Windows Based (hide the console)`

And press covert .py .exe
 
 
## Disclaimer:

This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. Educational purpose only!
